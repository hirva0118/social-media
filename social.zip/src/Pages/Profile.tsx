import { useNavigate } from "react-router-dom";
import { useAppDispatch, useAppSelector } from "../redux/store";
import { useEffect, useRef, useState } from "react";
import { getMyPost } from "../redux/Post/Slice";
import Drawer from "react-modern-drawer";
import { followerList, followingList } from "../redux/Profile/Slice";

const Profile = () => {
  const { userData } = useAppSelector((state) => state.profile);
  const { postData } = useAppSelector((state) => state.post);
  const [isFollowingOpen, setIsFollowingOpen] = useState(false);
  const [isFollowOpen, setIsFollowOpen] = useState(false);
  const followerData = useAppSelector((state) => state.profile.followerList);
  const followingData = useAppSelector((state) => state.profile.followingList);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const followerRef = useRef<HTMLDivElement>(null);
  const followingRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    dispatch(getMyPost());
  }, []);

  const handleEditProfile = () => {
    navigate("/editprofile");
  };

  const handleOpenPost = async (_id: string) => {
    try {
      // await dispatch(getSinglePostById({_id}));
      navigate(`/openpost/${_id}`);
    } catch (error) {
      console.log(error);
    }
  };

  const handleFollowingList = async (username: string) => {
    setIsFollowingOpen((prevstate) => !prevstate);
    await dispatch(followingList({ username }));
  };

  const handleFollowerList = async (username: string) => {
    setIsFollowOpen((prev) => !prev);
    await dispatch(followerList({ username }));
  };

  const handleDrawerClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        isFollowOpen &&
        followerRef.current &&
        !followerRef.current.contains(event.target as Node)
      ) {
        setIsFollowOpen(false);
      }
      if (
        isFollowingOpen &&
        followingRef.current &&
        !followerRef.current?.contains(event.target as Node)
      ) {
        setIsFollowingOpen(false);
      }
    };
    // Add event listener
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isFollowOpen,isFollowingOpen]);

  const handleFollowNavigation = (username: string | null) => {
    navigate(`/othersprofile/${username}`);
  }
  

  return (
    <div className="contain">
      <div className=" container">
        <div className="flex flex-row gap-4">
          <img
            className="h-16 w-16 border border-slate-300 rounded-full p-1"
            alt="profile image"
            src={
              userData?.coverImage?.url ||
              "https://newerahospitalnagpur.com/admin/uploads/donors/4549_ad.png"
            }
            onError={(e) =>
              (e.currentTarget.src =
                "https://newerahospitalnagpur.com/admin/uploads/donors/4549_ad.png")
            }
          />

          <div className="flex flex-row justify-between gap-2 w-[100%] items-center">
            <div className="flex flex-col items-center">
              <p className="font-semibold">{postData?.totalPosts}</p>
              <p>Posts</p>
            </div>
            <div className="flex flex-col items-center cursor-pointer">
              <p
                className="font-semibold"
                onClick={() =>
                  handleFollowerList(userData?.account?.username || "no")
                }
              >
                {userData?.followersCount}
              </p>
              <p>Followers</p>
              <Drawer
                open={isFollowOpen}
                direction="bottom"
                style={{
                  position: "fixed",
                  // width: "100%",
                  maxWidth: "350px",
                  left: "0",
                  right: "0",
                  marginLeft: "auto",
                  marginRight: "auto",
                  maxHeight: "80vh",
                  bottom: "0",
                }}
              >
                <div ref={followerRef} onClick={handleDrawerClick}>
                  <div className="flex justify-between bg-slate-200">
                    <p className="m-2 ">Follower's List: </p>
                    <img
                      className="w-5 h-5 cursor-pointer m-2"
                      alt="close"
                      src="https://icons.veryicon.com/png/o/miscellaneous/medium-thin-linear-icon/cross-23.png"
                      onClick={() => setIsFollowOpen(false)}
                    />
                  </div>
                  <ul>
                    {followerData?.followers.map((following) => (
                      <div className="flex gap-3 p-2">
                        <img
                          className="w-7 h-7"
                          alt="profile"
                          src={following.profile.coverImage.url}
                        />
                        <p className="cursor-pointer" onClick={() => handleFollowNavigation(following.username)}>{following.profile.firstName}{" "}{following.profile.lastName}</p>
                      </div>
                    ))}
                  </ul>
                </div>
              </Drawer>
            </div>

            <div className="flex flex-col items-center cursor-pointer">
              <p
                className="font-semibold"
                onClick={() =>
                  handleFollowingList(userData?.account.username || "No")
                }
              >
                {userData?.followingCount}
              </p>
              <p>Followings</p>
              <Drawer
                open={isFollowingOpen}
                direction="bottom"
                // size={180}
                style={{
                  position: "fixed",
                  // width: "100%",
                  maxWidth: "350px",
                  left: "0",
                  right: "0",
                  marginLeft: "auto",
                  marginRight: "auto",
                  maxHeight: "80vh",
                  bottom: "0",
                }}
              >
                <div ref={followingRef} onClick={handleDrawerClick}>
                  <div className="flex justify-between bg-slate-200">
                    <p className="m-2 ">Following's List :</p>
                    <img
                      className="w-5 h-5 cursor-pointer m-2"
                      alt="close"
                      src="https://icons.veryicon.com/png/o/miscellaneous/medium-thin-linear-icon/cross-23.png"
                      onClick={() => setIsFollowingOpen(false)}
                    />
                  </div>
                  <ul>
                    {followingData?.following.map((follow) => (
                      <div className="flex gap-3 p-2">
                        <img
                          className="w-7 h-7"
                          alt="profile"
                          src={follow.profile.coverImage.url}
                        />
                        <p className="cursor-pointer" onClick={() => handleFollowNavigation(follow.username)}>{follow.profile.firstName}{" "}{follow.profile.lastName}</p>
                      </div>
                    ))}
                  </ul>
                </div>
              </Drawer>
            </div>
          </div>
        </div>
        <div className="pt-3 pb-4">
          <p className="font-semibold">
            {userData?.firstName} {userData?.lastName}
          </p>
          <p>{userData?.bio}</p>
        </div>

        <button
          onClick={handleEditProfile}
          className=" p-1 w-full  border border-gray-200 rounded-lg font-semibold text-sm"
        >
          Edit Profile
        </button>
        <div className="grid grid-cols-3 gap-1 ">
          {postData.posts
            .slice()
            .sort(
              (a, b) =>
                new Date(b.createdAt).getTime() -
                new Date(a.createdAt).getTime()
            )
            .map((post) => {
              return (
                <div>
                  <img
                    key={post.images[0]._id}
                    className="w-24 h-28 pt-8 cursor-pointer "
                    alt="image"
                    src={post.images[0]?.url}
                    onClick={() => handleOpenPost(post._id)}
                  ></img>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default Profile;
