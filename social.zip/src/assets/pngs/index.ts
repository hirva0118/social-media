import Home1 from "../pngs/Home1.png";
import Plus from "../pngs/Plus.png";
import search from "../pngs/search.png";
import Instagram from "../pngs/Instagram.png"
import social from "../pngs/social.png"
export const Icons = {
    Home1,
    Plus,
    search,
    Instagram, 
    social,
}